from django.apps import AppConfig


class TodonoteappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'todonoteapp'
